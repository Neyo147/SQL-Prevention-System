# sqlprevention using html css js and php
SQL injection attack is widely used by attackers to gain unauthorized access to systems. This
software system is developed to prevent unauthorized access to system using SQL injection
attacks. This is done by adding unique value and a signature based authentication technique to
verify authenticity.
An SQL injection is a technique that attackers apply to insert SQL query into input fields to then be
processedby the underlying SQL database. These weaknesses are then able to be abused when
entry forms allow user- generated SQL statements to query the database directly.i have used  escaping techmique
,Always use character-escaping functions for user-supplied input provided by each
database management system (DBMS). This is done to make sure the DBMS never
confuses it with the SQLstatement provided by the developer.
Login1.php is method that calls without prevention whereas login2.php is with escaping technique
